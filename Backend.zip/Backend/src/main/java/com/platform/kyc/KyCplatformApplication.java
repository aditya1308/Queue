package com.platform.kyc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KyCplatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(KyCplatformApplication.class, args);
	}

}
